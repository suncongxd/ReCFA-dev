#include "ansidecl.h"
#include "version.h"

const char *const version_string = "3.2";
